<?php
$largura = 5;
$altura = 5;
$resultado = $largura * $altura;
echo "$resultado <br><br>";



$temperatura = 90;
$resultado =  ($temperatura * 9/5) + 32;
echo "$resultado <br><br>";


$valor = 56;
$total = 367;
$resultado = $valor * $total;
echo "$resultado <br><br>";

$nota1 = 6;
$nota2 = 7;
$nota3 = 9;
$resultado = ($nota1 + $nota2 + $nota3 / 3);
echo "$resultado <br><br>";

$nome = "Bolsonaro";
$profissao = "eletrecista";
echo "$nome é $profissao <br><br>";

$cidade = "Teresópolis";
$estado = "Goiania";
echo "$cidade - $estado <br><br>";

$palavra = "pai";
echo "Super $palavra <br><br>";

$nome =  "Jhoninhas";
$quant = 5;
$valor = 89.99;
$resultado = $quant * $valor;
echo " Você comprou  $quant cadernos por $valor <br><br>";


echo "Yago Gabriel Porn Christ <br>";