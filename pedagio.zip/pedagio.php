<?php

$veiculo = "caminhao";
$eixos = 6;

if ($veiculo == "moto"){
    echo "o valor é de R$ 2,90.";
}
else if ($veiculo == "carro"){
    echo "o valor é de R$ 5,80.";
}
else if ($veiculo == "caminhao"){
    $resultado = $eixos * 5.80;
    echo "o valor é de R$ $resultado.";
}






	
			
	